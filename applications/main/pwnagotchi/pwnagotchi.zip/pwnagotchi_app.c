#include "pwnagotchi_app.h"
#include "config.h"
#include "channel.h"
#include "pwnagotchi_detect.h"
#include "handshake.h"
#include "frame.h"
#include "deauth.h"
#include <gui/elements.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_log.h>
#include "../wlan_app/wlan_hal.h"
#define WORKER_STACK_SIZE 8192
#define EPOCH_INTERVAL_MS 100
static const char* get_face(PwnagotchiMood m) {
    switch(m) {
    case MoodHappy:    return "(^-^)";
    case MoodSad:      return "(; -;)";
    case MoodBroken:   return "(X-X)";
    case MoodIntense:  return "(>-<)";
    case MoodLooking:  return "(0-o)";
    case MoodSleeping: return "(-.-)";
    default:           return "('-')";
    }
}
static void render_cb(Canvas* const canvas, void* ctx) {
    PwnagotchiState* s = ctx;
    if(furi_mutex_acquire(s->mutex, 200) != FuriStatusOk) return;
    canvas_clear(canvas);
    canvas_set_color(canvas, ColorBlack);
    canvas_set_font(canvas, FontSecondary);
    int w = canvas_width(canvas);
    char buf[128];
    canvas_draw_str(canvas, 2, 7, g_config.version);
    canvas_draw_line(canvas, 0, 10, w, 10);
    canvas_set_font(canvas, FontSecondary);
    canvas_draw_str(canvas, 2, 21, "minigotchi>");
    snprintf(buf, sizeof(buf), "%s", s->epoch_status);
    canvas_draw_str(canvas, w - canvas_string_width(canvas, buf) - 2, 21, buf);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 4, 33, get_face(s->mood));
    canvas_set_font(canvas, FontSecondary);
    if(s->pwnagotchi_detected) {
        snprintf(buf, sizeof(buf), "%s %s", s->peer_type, s->peer_name);
        canvas_draw_str(canvas, 4, 42, buf);
    } else if(s->ap_name[0]) {
        snprintf(buf, sizeof(buf), "AP: %.16s", s->ap_name);
        canvas_draw_str(canvas, 4, 42, buf);
    }
    canvas_draw_line(canvas, 0, 50, w, 50);
    snprintf(buf, sizeof(buf), "CH:%d  PWND:%lu/%lu",
             s->current_channel,
             (unsigned long)s->pwnd_run,
             (unsigned long)s->pwnd_tot);
    canvas_draw_str(canvas, 2, 61, buf);
    snprintf(buf, sizeof(buf), "UP:%lus", (unsigned long)s->uptime_secs);
    canvas_draw_str(canvas, w - canvas_string_width(canvas, buf) - 2, 61, buf);
    furi_mutex_release(s->mutex);
}
static void input_cb(InputEvent* ev, void* ctx) {
    furi_assert(ctx);
    FuriMessageQueue* q = ctx;
    PluginEvent e = {.type = EventTypeKey, .input = *ev};
    furi_message_queue_put(q, &e, FuriWaitForever);
}
static void tick_cb(void* ctx) {
    furi_assert(ctx);
    FuriMessageQueue* q = ctx;
    PluginEvent e = {.type = EventTypeTick};
    furi_message_queue_put(q, &e, 0);
}
static void post_event(FuriMessageQueue* q, EventType t) {
    PluginEvent e = {.type = t};
    furi_message_queue_put(q, &e, 0);
}
static void worker_task(void* param) {
    PwnagotchiState* state = (PwnagotchiState*)param;
    FuriMessageQueue* q = state->event_queue;
    if(!wlan_hal_start()) {
        ESP_LOGE(TAG, "WiFi init failed");
        post_event(q, EventTypeWifiError);
        state->worker_running = false;
        vTaskDelete(NULL);
        return;
    }
    wlan_hal_set_promiscuous(true, pwnagotchi_promisc_cb);
    wlan_hal_set_channel((uint8_t)g_config.init_channel);
    state->wifi_started = true;
    post_event(q, EventTypeEpochDone);
    int epoch_step = 0;
    int epochs_since_peer = 0;
    while(state->worker_running) {
        g_config.uptime = config_uptime_secs();
        switch(epoch_step) {
        case 0: 
            channel_cycle();
            {
                furi_mutex_acquire(state->mutex, FuriWaitForever);
                state->current_channel = channel_get();
                strncpy(state->epoch_status, "zzZ *snrt*", sizeof(state->epoch_status) - 1);
                state->mood = MoodSleeping;
                furi_mutex_release(state->mutex);
            }
            post_event(q, EventTypeEpochDone);
            furi_delay_ms(g_config.short_delay_ms);
            break;
        case 1: 
            {
                furi_mutex_acquire(state->mutex, FuriWaitForever);
                strncpy(state->epoch_status, "who dat?", sizeof(state->epoch_status) - 1);
                state->mood = MoodLooking;
                furi_mutex_release(state->mutex);
            }
            post_event(q, EventTypeEpochDone);
            pwnagotchi_detect();
            if(g_pwnagotchi_detected) {
                epochs_since_peer = 0;
                furi_mutex_acquire(state->mutex, FuriWaitForever);
                state->pwnagotchi_detected = true;
                state->mood = MoodHappy;
                strncpy(state->epoch_status, "yay a fren!", sizeof(state->epoch_status) - 1);
                strncpy(state->peer_name, g_last_peer.name, sizeof(state->peer_name) - 1);
                strncpy(state->peer_type, g_last_peer.device_type, sizeof(state->peer_type) - 1);
                strncpy(state->peer_pwnd, g_last_peer.pwnd_tot, sizeof(state->peer_pwnd) - 1);
                furi_mutex_release(state->mutex);
                post_event(q, EventTypePwnDetected);
            } else {
                epochs_since_peer++;
                furi_mutex_acquire(state->mutex, FuriWaitForever);
                state->pwnagotchi_detected = false;
                if(epochs_since_peer > 10) {
                    state->mood = MoodBroken;
                    strncpy(state->epoch_status, "ded x_x", sizeof(state->epoch_status) - 1);
                } else if(epochs_since_peer > 5) {
                    state->mood = MoodSad;
                    strncpy(state->epoch_status, "so alone", sizeof(state->epoch_status) - 1);
                } else {
                    state->mood = MoodNeutral;
                    strncpy(state->epoch_status, "no frens yet", sizeof(state->epoch_status) - 1);
                }
                memset(state->peer_name, 0, sizeof(state->peer_name));
                furi_mutex_release(state->mutex);
                post_event(q, EventTypePwnLost);
            }
            break;
        case 2: 
            if(!g_config.deauth) break;
            {
                furi_mutex_acquire(state->mutex, FuriWaitForever);
                strncpy(state->epoch_status, "DIE AP DIE", sizeof(state->epoch_status) - 1);
                state->mood = MoodIntense;
                furi_mutex_release(state->mutex);
            }
            post_event(q, EventTypeEpochDone);
            handshake_start_capture();
            deauth_run();
            char target_essid[33];
            uint8_t target_bssid[6];
            deauth_get_target(target_essid, sizeof(target_essid), target_bssid);
            furi_mutex_acquire(state->mutex, FuriWaitForever);
            strncpy(state->ap_name, target_essid, sizeof(state->ap_name) - 1);
            memcpy(state->ap_bssid, target_bssid, 6);
            furi_mutex_release(state->mutex);
            furi_delay_ms(2000);
            post_event(q, EventTypeDeauthDone);
            break;
        case 3: 
            if(!g_config.advertise) break;
            {
                furi_mutex_acquire(state->mutex, FuriWaitForever);
                strncpy(state->epoch_status, "heya new frens", sizeof(state->epoch_status) - 1);
                state->mood = MoodIntense;
                furi_mutex_release(state->mutex);
            }
            post_event(q, EventTypeEpochDone);
            frame_advertise();
            {
                furi_mutex_acquire(state->mutex, FuriWaitForever);
                state->pwnd_run = (uint32_t)g_config.pwnd_run;
                state->pwnd_tot = (uint32_t)g_config.pwnd_tot;
                if(state->mood == MoodSad || state->mood == MoodBroken || state->mood == MoodSleeping) {
                } else if(epochs_since_peer < 3) {
                    state->mood = MoodHappy;
                    strncpy(state->epoch_status, "yay a fren!", sizeof(state->epoch_status) - 1);
                } else if(config_random(0, 100) < 20) {
                    state->mood = MoodLooking;
                    strncpy(state->epoch_status, "ooh what's that?", sizeof(state->epoch_status) - 1);
                } else {
                    state->mood = MoodNeutral;
                    strncpy(state->epoch_status, "just chillin", sizeof(state->epoch_status) - 1);
                }
                furi_mutex_release(state->mutex);
            }
            post_event(q, EventTypeAdvertDone);
            break;
        default:
            break;
        }
        epoch_step = (epoch_step + 1) % 4;
        furi_delay_ms(EPOCH_INTERVAL_MS);
    }
    wlan_hal_set_promiscuous(false, NULL);
    wlan_hal_stop();
    vTaskDelete(NULL);
}
int32_t pwnagotchi_app(void* p) {
    UNUSED(p);
    PwnagotchiState* state = malloc(sizeof(PwnagotchiState));
    memset(state, 0, sizeof(*state));
    state->mood = MoodNeutral;
    state->event_queue = furi_message_queue_alloc(16, sizeof(PluginEvent));
    state->mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    config_init();
    ViewPort* vp = view_port_alloc();
    view_port_draw_callback_set(vp, render_cb, state);
    view_port_input_callback_set(vp, input_cb, state->event_queue);
    FuriTimer* timer = furi_timer_alloc(tick_cb, FuriTimerTypePeriodic, state->event_queue);
    furi_timer_start(timer, furi_kernel_get_tick_frequency());
    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, vp, GuiLayerFullscreen);
    wlan_hal_bt_stop();
    state->worker_running = true;
    TaskHandle_t worker_handle;
    xTaskCreate(worker_task, "PwnWorker", WORKER_STACK_SIZE, state, 5, &worker_handle);
    PluginEvent event;
    bool running = true;
    while(running) {
        FuriStatus s = furi_message_queue_get(state->event_queue, &event, 100);
        if(s != FuriStatusOk) continue;
        if(furi_mutex_acquire(state->mutex, FuriWaitForever) != FuriStatusOk) continue;
        switch(event.type) {
        case EventTypeKey:
            if(event.input.type == InputTypeShort && event.input.key == InputKeyBack) {
                running = false;
            }
            break;
        case EventTypeTick:
            state->uptime_secs++;
            break;
        case EventTypePwnDetected:
        case EventTypePwnLost:
        case EventTypeAdvertDone:
        case EventTypeEpochDone:
            state->current_channel = channel_get();
            break;
        case EventTypeDeauthDone: {
            state->current_channel = channel_get();
            uint32_t new_hs = handshake_process(
                state->ap_name, state->ap_bssid);
            if (new_hs == 0xFFFFFFFF) {
                strncpy(state->epoch_status, "Missed 4way", sizeof(state->epoch_status) - 1);
                state->mood = MoodSad;
                memset(state->ap_name, 0, sizeof(state->ap_name));
                memset(state->ap_bssid, 0, sizeof(state->ap_bssid));
                view_port_update(vp);
                furi_mutex_release(state->mutex);
                furi_delay_ms(1000);
                if (furi_mutex_acquire(state->mutex, FuriWaitForever) != FuriStatusOk) continue;
                break;
            } else if(new_hs > 0) {
                state->pwnd_run += new_hs;
                state->pwnd_tot += new_hs;
                g_config.pwnd_run += new_hs;
                g_config.pwnd_tot += new_hs;
                ESP_LOGI(TAG, "Captured %lu handshake(s)!", (unsigned long)new_hs);
            }
            memset(state->ap_name, 0, sizeof(state->ap_name));
            memset(state->ap_bssid, 0, sizeof(state->ap_bssid));
            break;
        }
        case EventTypeWifiError:
            ESP_LOGE(TAG, "WiFi error, shutting down");
            running = false;
            break;
        }
        view_port_update(vp);
        furi_mutex_release(state->mutex);
    }
    state->worker_running = false;
    furi_delay_ms(200);
    furi_timer_free(timer);
    view_port_enabled_set(vp, false);
    gui_remove_view_port(gui, vp);
    furi_record_close(RECORD_GUI);
    wlan_hal_bt_restore();
    view_port_free(vp);
    furi_message_queue_free(state->event_queue);
    furi_mutex_free(state->mutex);
    free(state);
    handshake_deinit();
    return 0;
}